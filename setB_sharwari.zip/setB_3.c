#include<stdio.h>    
#include<stdlib.h>  

void reverseBits(int a[],int n)
{
   int i,j=0;
   for(i=0;n>0;i++)    
   {    
      a[i]=n%2;
      n=n/2;
      j++;
   }    
   printf("\nBefore:");    
   for(i=i-1;i>=0;i--)    
   {    
      printf("%d",a[i]);    
   }
   printf(" After:");
   for(i=0;i<j;i++)
   {
      printf("%d",a[i]);
   }
   printf("\n");
}

int main(){  
   int a[16],n,i,j=0;    
   printf("Enter the number to convert: ");    
   scanf("%d",&n);
   reverseBits(a,n);
   return 0;  
}  
