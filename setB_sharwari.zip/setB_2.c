#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int findChilds(char* parent, char **childs) {
    FILE* fp = fopen("file.txt", "r");
    if (fp == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }
    char line[100];

    int count = 0;
    while (fgets(line, sizeof(line), fp)) {
        char *child = strtok(line, " ");
        char *tparent = strtok(NULL, " ");
       
        tparent[strlen(tparent) - 1] = '\0';

        if (strcmp(parent, tparent) == 0) {
            childs[count] = (char*)malloc(sizeof(char)*100);
            strcpy(childs[count], child);
            count++;
        }
    }  
    fclose(fp);
    return count;
}
int main() {
    char name[50];
    printf("Enter the string");
    scanf("%s", name);

    char** childs = (char*)malloc(sizeof(char) * 100);
    int child_count = findChilds(name, childs);
    int grandchild_count = 0;
    for (int j = 0; j < child_count; j++) {
        char** temp = (char*)malloc(sizeof(char) * 100);
        grandchild_count += findChilds(childs[j], temp);
       
    }

    printf("Number of grandchildren %d\n", grandchild_count);
    return 0;
}
